from godot import exposed, export
from godot import KinematicBody2D, Vector2, Input

@exposed
class Player(KinematicBody2D):
	a = export(int)
	b = export(str, default='foo')

	def _ready(self):
		self.move_speed = 40.0
		self.animation_player = self.get_node("AnimationPlayer")
		self.last_move_vector = Vector2()
		self.connect("body_entered", self._on_collision)

	def _physics_process(self, delta):
		input_state = Input
		move_vector = Vector2()
		
		if input_state.is_action_pressed("ui_right"):
			move_vector.x = 1
		elif input_state.is_action_pressed("ui_left"):
			move_vector.x = -1
		elif input_state.is_action_pressed("ui_down"):
			move_vector.y = 1
		elif input_state.is_action_pressed("ui_up"):
			move_vector.y = -1

		if move_vector.length() > 0:
			move_vector = move_vector.normalized()
			move_vector *= self.move_speed
			self.move_and_slide(move_vector)

		self.update_animation(move_vector)
		self.last_move_vector = move_vector

	def update_animation(self, move_vector):
		if move_vector.x > 0:
			self.animation_player.play("WalkRight")
		elif move_vector.x < 0:
			self.animation_player.play("WalkLeft")
		elif move_vector.y > 0:
			self.animation_player.play("WalkDown")
		elif move_vector.y < 0:
			self.animation_player.play("WalkUp")
		else:
			if self.last_move_vector.x > 0:
				self.animation_player.play("IdleRight")
			elif self.last_move_vector.x < 0:
				self.animation_player.play("IdleLeft")
			elif self.last_move_vector.y > 0:
				self.animation_player.play("IdleDown")
			elif self.last_move_vector.y < 0:
				self.animation_player.play("IdleUp")
